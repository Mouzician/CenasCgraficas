A folder named CGF, including the CGF*.h headers from CGFlib should be placed in this folder.
If it is missing, please obtain it from the binary distributable or recompile from source.